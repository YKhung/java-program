package p2;

import java.io.File;
import java.io.IOException;

public class MinHashAccuracy {
	private String foldername;
	private double error;
	private int permutations;
	public MinHashAccuracy(String foldername,double error,int permutations){
		this.foldername = foldername;
		this.error = error;
		this.permutations = permutations;
	}
	public int calulatePair() throws IOException{
		
		MinHash minHash = new MinHash(foldername, permutations);
		File f=null;
		f=new File(foldername);                 
		File[] list=f.listFiles(); 
		int size = 0;
		for(int i=0;i<list.length -1;i++){
			for(int j=i+1;j<list.length;j++){
				double a = minHash.approximateJaccard(list[i].getName(), list[j].getName());
				double b = minHash.exactJaccard(list[i].getName(), list[j].getName());
				//System.out.println("a="+a+";"+"b="+b);
				if(Math.abs(a-b) > error) {
					size++;
				}
			}
		}

		return size;
		
	}
}
