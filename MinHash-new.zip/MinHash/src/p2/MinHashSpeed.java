package p2;

import java.io.File;
import java.io.IOException;

public class MinHashSpeed {
	private MinHash minHash;
	private String foldername;
	public MinHashSpeed(String foldername,int permutations) throws IOException {
		this.foldername = foldername;
		 minHash = new MinHash(foldername, permutations);
	}
	public long calulateExacttime() {
		long startTime=System.currentTimeMillis();
		File f=null;
		f=new File(foldername);                 
		File[] list=f.listFiles(); 
		for(int i=0;i<list.length -1;i++){
			for(int j=i+1;j<list.length;j++){
				//double a = minHash.approximateJaccard(list[i].getName(), list[j].getName());
				minHash.exactJaccard(list[i].getName(), list[j].getName());
				//System.out.println("a="+a+";"+"b="+b);

			}
		}

		long endTime=System.currentTimeMillis(); 

		return (endTime-startTime)/1000; 
		
	}
	public long calulateEstimatetime() throws IOException {
		long startTime=System.currentTimeMillis();
		File f=null;
		f=new File(foldername);                 
		File[] list=f.listFiles(); 
		for(int i=0;i<list.length -1;i++){
			for(int j=i+1;j<list.length;j++){
				minHash.approximateJaccard(list[i].getName(), list[j].getName());
				//minHash.exactJaccard(list[i].getName(), list[j].getName());
				//System.out.println("a="+a+";"+"b="+b);

			}
		}

		long endTime=System.currentTimeMillis(); 

		return (endTime-startTime)/1000; 
		
	}
}
