package p2;

import java.io.IOException;
public class Test {
	public static void main(String[] args) throws IOException{

		MinHash minHash = new MinHash("C:/Users/xianqin/Desktop/space", 600);
		System.out.println(minHash.approximateJaccard("space-0.txt", "space-1.txt"));
		System.out.println(minHash.exactJaccard("space-0.txt", "space-1.txt"));
//		MinHashAccuracy minHash = new MinHashAccuracy("C:/Users/xianqin/Desktop/space",0.02, 400);
//		System.out.println(minHash.calulatePair());

		//System.out.println(minHash.minHashMatrix());
//		MinHashSpeed minHash = new MinHashSpeed("C:/Users/xianqin/Desktop/space",400);
//		System.out.println(minHash.calulateExacttime());
	}
}
